package th.antipro;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Player;
import org.bukkit.entity.Shulker;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CheckListener implements Listener {

    private final AntiPro plugin;
    private final Map<UUID, Integer> hover = new HashMap<>();
    private final Map<UUID, Integer> groundSpoof = new HashMap<>();
    private final Map<UUID, Long> exempt = new HashMap<>();
    private final Map<UUID, long[]> clicks = new HashMap<>();
    private final Map<UUID, long[]> timer = new HashMap<>();       // {lastTime, balance}
    private final Map<UUID, Long> popTime = new HashMap<>();
    private final Map<UUID, ArrayDeque<Long>> refills = new HashMap<>();
    private final Map<UUID, Integer> lastHitTick = new HashMap<>();
    private final Map<UUID, UUID> lastHitTarget = new HashMap<>();

    public CheckListener(AntiPro plugin) {
        this.plugin = plugin;
    }

    // ================= helpers =================
    private void exempt(Player p, long ms) {
        UUID id = p.getUniqueId();
        exempt.put(id, System.currentTimeMillis() + ms);
        hover.remove(id);
        groundSpoof.remove(id);
        timer.remove(id);
    }

    private boolean isExempt(Player p) {
        Long t = exempt.get(p.getUniqueId());
        return t != null && System.currentTimeMillis() < t;
    }

    private boolean on(String check) {
        return plugin.getConfig().getBoolean("checks." + check + ".enabled", true);
    }

    private double cfg(String path, double def) {
        return plugin.getConfig().getDouble("checks." + path, def);
    }

    // ================= exemptions =================
    @EventHandler public void onJoin(PlayerJoinEvent e) { exempt(e.getPlayer(), 3000); }
    @EventHandler public void onTp(PlayerTeleportEvent e) { exempt(e.getPlayer(), 1500); }
    @EventHandler public void onRespawn(PlayerRespawnEvent e) { exempt(e.getPlayer(), 2000); }
    @EventHandler public void onVelocity(PlayerVelocityEvent e) { exempt(e.getPlayer(), 2000); }
    @EventHandler public void onRiptide(PlayerRiptideEvent e) { exempt(e.getPlayer(), 3500); }
    @EventHandler public void onGm(PlayerGameModeChangeEvent e) { exempt(e.getPlayer(), 3000); }

    @EventHandler
    public void onVehicleExit(VehicleExitEvent e) {
        if (e.getExited() instanceof Player p) exempt(p, 1500);
    }

    @EventHandler
    public void onDamaged(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) exempt(p, 1000);
    }

    @EventHandler
    public void onLaunch(ProjectileLaunchEvent e) {
        if (e.getEntityType() == EntityType.WIND_CHARGE && e.getEntity().getShooter() instanceof Player p) {
            exempt(p, 4000);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        hover.remove(id); groundSpoof.remove(id); exempt.remove(id); clicks.remove(id);
        timer.remove(id); popTime.remove(id); refills.remove(id);
        lastHitTick.remove(id); lastHitTarget.remove(id);
        plugin.clear(id);
    }

    // ================= movement: Timer / GroundSpoof / Fly / Speed =================
    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedPosition()) return;
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR || p.getAllowFlight() || p.isFlying()
                || p.isGliding() || p.isInsideVehicle() || p.isRiptiding() || p.isDead()) {
            hover.remove(id); groundSpoof.remove(id); timer.remove(id);
            return;
        }
        if (isExempt(p)) return;

        Location from = e.getFrom(), to = e.getTo();
        double dx = to.getX() - from.getX(), dz = to.getZ() - from.getZ();
        double dy = to.getY() - from.getY();
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        // ---- Timer (ส่งแพ็กเก็ตเร็วกว่า 20/วินาที) ----
        if (on("timer")) {
            long now = System.currentTimeMillis();
            long cap = (long) cfg("timer.max-lag-ms", 1000);
            long[] t = timer.get(id);
            if (t == null) {
                timer.put(id, new long[]{now, cap});
            } else {
                long delta = now - t[0];
                t[0] = now;
                t[1] = Math.min(cap, t[1] + 50 - delta);
                if (t[1] < -50) {
                    plugin.flag(p, "Timer", "balance=" + t[1] + "ms");
                    t[1] = cap;
                    e.setTo(from);
                    return;
                }
            }
        }

        // ---- GroundSpoof / NoFall ----
        if (on("groundspoof")) {
            if (!p.isOnGround() || hasSupport(to)) {
                groundSpoof.remove(id);
            } else {
                int c = groundSpoof.merge(id, 1, Integer::sum);
                if (c >= 4) {
                    if (nearSpecial(p) || entitySupport(p)) {
                        groundSpoof.remove(id);
                    } else {
                        plugin.flag(p, "GroundSpoof", "onGround ทั้งที่ไม่มีบล็อกใต้เท้า");
                        groundSpoof.put(id, 2);
                    }
                }
            }
        }

        // ---- Fly ----
        if (on("fly")) {
            // พุ่งขึ้นเร็วเกินกระโดด
            PotionEffect jb = p.getPotionEffect(PotionEffectType.JUMP_BOOST);
            double upMax = 0.65 + (jb == null ? 0 : 0.1 * (jb.getAmplifier() + 1));
            if (dy > upMax && !nearSpecial(p) && !p.hasPotionEffect(PotionEffectType.LEVITATION)) {
                plugin.flag(p, "Fly", String.format("up dy=%.3f > %.3f", dy, upMax));
                e.setTo(from);
                return;
            }
            // ลอยค้างกลางอากาศ
            if (!p.isOnGround() && dy >= -0.02) {
                int h = hover.merge(id, 1, Integer::sum);
                int need = plugin.getConfig().getInt("checks.fly.hover-ticks", 10);
                if (h >= need) {
                    if (nearSpecial(p) || p.hasPotionEffect(PotionEffectType.LEVITATION)
                            || p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) {
                        hover.remove(id);
                    } else {
                        plugin.flag(p, "Fly", String.format("hover=%d dy=%.3f", h, dy));
                        hover.put(id, need / 2);
                        e.setTo(from);
                        return;
                    }
                }
            } else {
                hover.remove(id);
            }
        }

        // ---- Speed ----
        if (on("speed")) {
            double max = cfg("speed.max-horizontal", 0.75);
            PotionEffect sp = p.getPotionEffect(PotionEffectType.SPEED);
            if (sp != null) max *= 1.0 + 0.2 * (sp.getAmplifier() + 1);
            max *= Math.max(1.0, p.getWalkSpeed() / 0.2);
            if (horizontal > max) {
                plugin.flag(p, "Speed", String.format("%.3f > %.3f", horizontal, max));
                e.setTo(from);
            }
        }
    }

    /** มีบล็อกตัน (หรือ powder snow) ใต้เท้าอย่างน้อย 1 จุดจาก 9 จุดของกล่องผู้เล่น */
    private boolean hasSupport(Location l) {
        double[] o = {-0.3, 0, 0.3};
        int by = (int) Math.floor(l.getY() - 0.1);
        for (double ox : o) {
            for (double oz : o) {
                Block b = l.getWorld().getBlockAt((int) Math.floor(l.getX() + ox), by,
                        (int) Math.floor(l.getZ() + oz));
                if (!b.isPassable() || b.getType() == Material.POWDER_SNOW) return true;
            }
        }
        return false;
    }

    private boolean entitySupport(Player p) {
        for (Entity en : p.getNearbyEntities(1.5, 2.0, 1.5)) {
            if (en instanceof Boat || en instanceof Minecart || en instanceof Shulker) return true;
        }
        return false;
    }

    private boolean nearSpecial(Player p) {
        Block base = p.getLocation().getBlock();
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                for (int y = -1; y <= 2; y++) {
                    Block b = base.getRelative(x, y, z);
                    Material m = b.getType();
                    if (b.isLiquid() || Tag.CLIMBABLE.isTagged(m) || m == Material.COBWEB
                            || m == Material.BUBBLE_COLUMN || m == Material.SLIME_BLOCK
                            || m == Material.HONEY_BLOCK || m == Material.POWDER_SNOW
                            || m == Material.SWEET_BERRY_BUSH) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // ================= combat: Reach / KillAura =================
    @EventHandler(ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

        Vector eye = p.getEyeLocation().toVector();
        BoundingBox box = e.getEntity().getBoundingBox();
        Vector closest = new Vector(
                clamp(eye.getX(), box.getMinX(), box.getMaxX()),
                clamp(eye.getY(), box.getMinY(), box.getMaxY()),
                clamp(eye.getZ(), box.getMinZ(), box.getMaxZ()));
        double dist = eye.distance(closest);

        if (on("reach")) {
            double max = cfg("reach.max-distance", 3.6);
            if (dist > max) {
                plugin.flag(p, "Reach", String.format("%.2f > %.2f", dist, max));
                e.setCancelled(true);
                return;
            }
        }
        if (on("killaura")) {
            // ตีนอกมุมมอง
            if (dist > 1.5) {
                double dot = p.getEyeLocation().getDirection().dot(box.getCenter().subtract(eye).normalize());
                if (dot < cfg("killaura.min-dot", 0.3)) {
                    plugin.flag(p, "KillAura", String.format("dot=%.2f", dot));
                    e.setCancelled(true);
                    return;
                }
            }
            // ตีหลายเป้าหมายใน tick เดียว
            UUID pid = p.getUniqueId(), tid = e.getEntity().getUniqueId();
            int tick = Bukkit.getCurrentTick();
            Integer lt = lastHitTick.get(pid);
            UUID lTarget = lastHitTarget.get(pid);
            lastHitTick.put(pid, tick);
            lastHitTarget.put(pid, tid);
            if (lt != null && lt == tick && lTarget != null && !lTarget.equals(tid)) {
                plugin.flag(p, "KillAura", "multi-target same tick");
                e.setCancelled(true);
            }
        }
    }

    private double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    // ================= AutoClicker =================
    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        if (!on("autoclicker") || e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = e.getPlayer();
        long now = System.currentTimeMillis();
        long[] w = clicks.computeIfAbsent(p.getUniqueId(), k -> new long[]{now, 0});
        if (now - w[0] >= 1000) { w[0] = now; w[1] = 0; }
        w[1]++;
        if (w[1] > (long) cfg("autoclicker.max-cps", 22)) {
            plugin.flag(p, "AutoClicker", "cps=" + w[1]);
            w[1] = 0;
        }
    }

    // ================= Nuker / block reach =================
    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (!on("nuker") || p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        Location center = e.getBlock().getLocation().add(0.5, 0.5, 0.5);
        double d = p.getEyeLocation().distance(center);
        double max = cfg("nuker.max-distance", 6.0);
        if (d > max) {
            plugin.flag(p, "Nuker", String.format("%.2f > %.2f", d, max));
            e.setCancelled(true);
        }
    }

    // ================= AutoTotem =================
    @EventHandler(ignoreCancelled = true)
    public void onPop(EntityResurrectEvent e) {
        if (e.getEntity() instanceof Player p) popTime.put(p.getUniqueId(), System.currentTimeMillis());
    }

    private boolean isTotem(ItemStack i) {
        return i != null && i.getType() == Material.TOTEM_OF_UNDYING;
    }

    /** @return true ถ้าผิดปกติ (ควร cancel การสลับ) */
    private boolean checkRefill(Player p) {
        UUID id = p.getUniqueId();
        Long t = popTime.remove(id);
        if (t == null || !on("autototem")) return false;
        long delay = System.currentTimeMillis() - t;
        if (delay > 2500) return false;

        long adjusted = delay - Math.max(0, p.getPing());
        boolean bad = false;
        long min = (long) cfg("autototem.min-delay-ms", 120);
        if (adjusted < min) {
            plugin.flag(p, "AutoTotem", "refill=" + delay + "ms ping=" + p.getPing() + "ms");
            bad = true;
        }

        // ดีเลย์นิ่งเกินคน (บอทที่ตั้งหน่วงเวลาไว้)
        ArrayDeque<Long> q = refills.computeIfAbsent(id, k -> new ArrayDeque<>());
        q.addLast(adjusted);
        if (q.size() > 5) q.removeFirst();
        if (!bad && q.size() >= 4) {
            double mean = 0;
            for (long v : q) mean += v;
            mean /= q.size();
            double var = 0;
            for (long v : q) var += (v - mean) * (v - mean);
            double std = Math.sqrt(var / q.size());
            if (std < cfg("autototem.consistency-std-ms", 6.0) && mean < 800) {
                plugin.flag(p, "AutoTotem", String.format("นิ่งผิดคน std=%.1fms mean=%.0fms", std, mean));
                q.clear();
                bad = true;
            }
        }
        return bad;
    }

    @EventHandler(ignoreCancelled = true)
    public void onInvClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !popTime.containsKey(p.getUniqueId())) return;
        boolean toOffhand =
                (e.getClick() == ClickType.SWAP_OFFHAND && isTotem(e.getCurrentItem()))
                || (e.getSlot() == 40 && isTotem(e.getCursor()))
                || (e.isShiftClick() && isTotem(e.getCurrentItem()));
        if (toOffhand && checkRefill(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwapHands(PlayerSwapHandItemsEvent e) {
        if (isTotem(e.getOffHandItem()) && checkRefill(e.getPlayer())) e.setCancelled(true);
    }
}
