package th.antipro;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class AntiPro extends JavaPlugin {

    private final Map<UUID, Map<String, Integer>> violations = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new CheckListener(this), this);
        long period = Math.max(1, getConfig().getLong("vl-decay-seconds", 30)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, this::decay, period, period);
        getLogger().info("AntiPro enabled.");
    }

    private void decay() {
        violations.values().forEach(m -> m.replaceAll((k, v) -> Math.max(0, v - 1)));
    }

    public void flag(Player p, String check, String info) {
        if (p.hasPermission("antipro.bypass")) return;
        Map<String, Integer> map = violations.computeIfAbsent(p.getUniqueId(), k -> new ConcurrentHashMap<>());
        int vl = map.merge(check, 1, Integer::sum);

        if (getConfig().getBoolean("alerts", true)) {
            String msg = "§c[AntiPro] §f" + p.getName() + " §7failed §e" + check
                    + " §7(VL " + vl + ") §8" + info;
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("antipro.alerts")) staff.sendMessage(msg);
            }
            getLogger().info(p.getName() + " failed " + check + " VL=" + vl + " " + info);
        }

        int limit = getConfig().getInt("checks." + check.toLowerCase() + ".punish-vl", 10);
        if (vl >= limit) {
            map.put(check, 0);
            punish(p, check);
        }
    }

    private void punish(Player p, String check) {
        String def = getConfig().getString("punishment.default-action", "tp_clear");
        String action = getConfig().getString("checks." + check.toLowerCase() + ".action", def);
        getLogger().warning("PUNISH " + p.getName() + " check=" + check + " action=" + action);

        if (action.equalsIgnoreCase("kick")) {
            String msg = getConfig().getString("punishment.kick-message", "§cCheating detected")
                    .replace("%check%", check);
            p.kick(Component.text(msg));
            return;
        }

        // tp_clear: ปิด GUI (คืนของใน crafting grid) -> เซฟของ -> ล้าง -> วาร์ป
        p.closeInventory();
        p.leaveVehicle();
        saveInventory(p, check);
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setArmorContents(new ItemStack[4]);
        inv.setItemInOffHand(new ItemStack(Material.AIR));
        p.setItemOnCursor(new ItemStack(Material.AIR));
        p.teleport(punishLocation(p));
        p.sendMessage("§c[AntiPro] ตรวจพบการโกง (" + check + ") ของในตัวถูกล้างและคุณถูกวาร์ป");
    }

    private Location punishLocation(Player p) {
        String wn = getConfig().getString("punishment.teleport.world", "");
        World w = (wn == null || wn.isEmpty()) ? null : Bukkit.getWorld(wn);
        if (w == null) w = p.getWorld();
        double x = getConfig().getDouble("punishment.teleport.x", -41);
        double y = getConfig().getDouble("punishment.teleport.y", 46);
        double z = getConfig().getDouble("punishment.teleport.z", -22);
        if (getConfig().getBoolean("punishment.teleport.center", true)) { x += 0.5; z += 0.5; }
        Location cur = p.getLocation();
        return new Location(w, x, y, z, cur.getYaw(), cur.getPitch());
    }

    private File clearedDir() {
        File d = new File(getDataFolder(), "cleared");
        d.mkdirs();
        return d;
    }

    private void saveInventory(Player p, String check) {
        try {
            YamlConfiguration y = new YamlConfiguration();
            y.set("player", p.getName());
            y.set("check", check);
            y.set("items", Arrays.asList(p.getInventory().getContents()));
            y.save(new File(clearedDir(), p.getUniqueId() + "_" + System.currentTimeMillis() + ".yml"));
        } catch (IOException ex) {
            getLogger().severe("Cannot save inventory of " + p.getName() + ": " + ex.getMessage());
        }
    }

    private boolean restore(Player p) {
        File[] files = clearedDir().listFiles((d, n) -> n.startsWith(p.getUniqueId() + "_") && n.endsWith(".yml"));
        if (files == null || files.length == 0) return false;
        Arrays.sort(files);
        File f = files[files.length - 1];
        List<?> list = YamlConfiguration.loadConfiguration(f).getList("items");
        if (list == null) return false;
        PlayerInventory inv = p.getInventory();
        ItemStack[] arr = new ItemStack[inv.getSize()];
        for (int i = 0; i < Math.min(arr.length, list.size()); i++) {
            Object o = list.get(i);
            arr[i] = (o instanceof ItemStack is) ? is : null;
        }
        inv.setContents(arr);
        f.renameTo(new File(f.getParentFile(), f.getName() + ".restored"));
        return true;
    }

    public void clear(UUID id) {
        violations.remove(id);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1 && a[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            s.sendMessage("§aAntiPro reloaded.");
            return true;
        }
        if (a.length == 2 && a[0].equalsIgnoreCase("vl")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            if (t == null) { s.sendMessage("§cไม่พบผู้เล่น"); return true; }
            s.sendMessage("§eVL ของ " + t.getName() + ": §f"
                    + violations.getOrDefault(t.getUniqueId(), Map.of()));
            return true;
        }
        if (a.length == 2 && a[0].equalsIgnoreCase("restore")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            if (t == null) { s.sendMessage("§cผู้เล่นต้องออนไลน์"); return true; }
            s.sendMessage(restore(t) ? "§aคืนของให้ " + t.getName() + " แล้ว (ทับของในตัวปัจจุบัน)"
                                     : "§cไม่พบไฟล์ของที่เคยล้าง");
            return true;
        }
        s.sendMessage("§e/antipro reload | vl <player> | restore <player>");
        return true;
    }
}
